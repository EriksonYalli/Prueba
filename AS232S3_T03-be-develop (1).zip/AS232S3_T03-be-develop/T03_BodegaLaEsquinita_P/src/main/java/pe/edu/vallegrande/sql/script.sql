USE master;
GO

-- Drop the database if it already exists
IF EXISTS (SELECT name
           FROM master.dbo.sysdatabases
           WHERE name = N'dbLaEsquinita')
DROP DATABASE dbLaEsquinita;
GO

CREATE DATABASE dbLaEsquinita;
GO

USE dbLaEsquinita;
GO

-- Crear esquemas
CREATE SCHEMA Productos;
GO
CREATE SCHEMA Vendedores;
GO
CREATE SCHEMA Clientes;
GO
CREATE SCHEMA Proveedores;
GO

-- Tabla: Supplier (Proveedores)
CREATE TABLE Proveedores.Supplier
(
    id                   INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    name                 VARCHAR(40)        NOT NULL,
    direction            VARCHAR(100)       NOT NULL,
    email                VARCHAR(60)        NOT NULL,
    ruc                  CHAR(11)           NOT NULL UNIQUE,
    representative       VARCHAR(60)        NOT NULL,
    email_representative VARCHAR(60)        NOT NULL,
    phone_representative CHAR(9)            NOT NULL,
    status               CHAR(1)            NOT NULL DEFAULT 'A',
    code_supplier        CHAR(4)            NOT NULL UNIQUE
);
GO

-- Tabla: Seller (Vendedores)
CREATE TABLE Vendedores.Seller
(
    id        INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    name      VARCHAR(60)        NOT NULL,
    last_name VARCHAR(60)        NOT NULL,
    dni       CHAR(8)            NOT NULL UNIQUE,
    email     VARCHAR(60)        NOT NULL,
    phone     CHAR(9)            NOT NULL,
    post      VARCHAR(50)        NOT NULL,
    password  VARCHAR(30)        NOT NULL
);
GO

-- Restricciones para Seller
ALTER TABLE Vendedores.Seller
    ADD CONSTRAINT chk_name_no_numbers
        CHECK (name NOT LIKE '%[0-9]%'),
    CONSTRAINT chk_last_name_no_numbers
    CHECK (last_name NOT LIKE '%[0-9]%'),
    CONSTRAINT chk_seller_dni_length
    CHECK (LEN(dni) = 8),
    CONSTRAINT CK_email_format
    CHECK (email LIKE '%_@__%.__%'),
    CONSTRAINT chk_seller_phone_only_numbers
    CHECK (phone NOT LIKE '%[^0-9]%');
GO

-- Tabla: Customer (Clientes)
CREATE TABLE Clientes.Customer
(
    id              INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    name            VARCHAR(50)        NOT NULL,
    last_name       VARCHAR(50)        NOT NULL,
    document_type   VARCHAR(20)        NOT NULL,
    number_document VARCHAR(20)        NOT NULL,
    birthdate       DATE               NOT NULL,
    phone           CHAR(9)            NOT NULL,
    email           VARCHAR(100)       NOT NULL,
    address         VARCHAR(100)       NOT NULL,
    status          CHAR(1)            NOT NULL DEFAULT 'A'
);
GO

-- Restricciones para Customer
ALTER TABLE Clientes.Customer
    ADD CONSTRAINT CK_birthdate_age
        CHECK (birthdate <= DATEADD(YEAR, -18, GETDATE()));
GO

-- Tabla: Product (Productos)
CREATE TABLE Productos.Product
(
    id              INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    name            VARCHAR(60)        NOT NULL,
    category        VARCHAR(50)        NOT NULL,
    description     VARCHAR(100)       NOT NULL,
    trade_mark      VARCHAR(40)        NOT NULL,
    stock           INT                NOT NULL,
    price           DECIMAL(10, 2)     NOT NULL,
    expiration_date DATE               NOT NULL,
    status          CHAR(1)            NOT NULL DEFAULT 'A',
    code_product    CHAR(4)            NOT NULL
);
GO

-- Restricciones para Product
ALTER TABLE Productos.Product
    ADD CONSTRAINT chk_product_stock
        CHECK (stock >= 1),
    CONSTRAINT chk_date_future
    CHECK (expiration_date >= GETDATE()),
    CONSTRAINT chk_product_price_positive
    CHECK (price > 0);
GO

-- Tabla: Sale (Ventas)
CREATE TABLE dbo.Sale
(
    id             INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    customer_id    INT                NOT NULL,
    seller_id      INT                NOT NULL,
    date_sale      DATE               NOT NULL,
    payment_method VARCHAR(20)        NOT NULL,
    status         CHAR(1)            NOT NULL DEFAULT 'A',
    total_sale     DECIMAL(10, 2)     NOT NULL
);
GO

-- Tabla: Sale_Detail (Detalle de Ventas)
CREATE TABLE dbo.Sale_Detail
(
    id         INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    sale_id    INT                NOT NULL,
    product_id INT                NOT NULL,
    amount     INT                NOT NULL,
    unit_price DECIMAL(10, 2)     NOT NULL,
    subtotal   DECIMAL(10, 2)     NOT NULL
);
GO

-- Tabla: Supplier_Order (Órdenes de Proveedores)
CREATE TABLE dbo.Supplier_Order
(
    id_supplier_order   INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    order_date          DATETIME           NOT NULL,
    delivery_date       DATETIME           NOT NULL,
    supplier_id         INT                NOT NULL,
    code_order_supplier CHAR(5)            NOT NULL,
    order_status        CHAR(1)            NOT NULL DEFAULT 'A'
);
GO

-- Tabla: Supplier_Order_Detail (Detalle de Órdenes de Proveedores)
CREATE TABLE dbo.Supplier_Order_Detail
(
    id_supplier_order_detail INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    product_id               INT                NOT NULL,
    quantity                 INT                NOT NULL,
    unit_price               DECIMAL(10, 2)     NOT NULL,
    total_price              DECIMAL(10, 2)     NOT NULL,
    supplier_order_id        INT                NOT NULL,
    description              VARCHAR(60)        NOT NULL
);
GO

-- Tabla: Inventory (Inventario)
CREATE TABLE dbo.Inventory
(
    id_inventory      INT IDENTITY (1,1) NOT NULL PRIMARY KEY,
    product_id        INT                NOT NULL,
    entry_date        DATE               NOT NULL,
    exit_date         DATE               NULL,
    purchase_price    DECIMAL(10, 2)     NOT NULL,
    sale_price        DECIMAL(10, 2)     NOT NULL,
    supplier_id       INT                NOT NULL,
    amount            INT                NOT NULL,
    description       VARCHAR(80)        NOT NULL
);
GO

-- Relaciones
ALTER TABLE dbo.Sale
    ADD FOREIGN KEY (customer_id) REFERENCES Clientes.Customer(id),
    FOREIGN KEY (seller_id) REFERENCES Vendedores.Seller(id);

ALTER TABLE dbo.Sale_Detail
    ADD FOREIGN KEY (sale_id) REFERENCES dbo.Sale(id),
    FOREIGN KEY (product_id) REFERENCES Productos.Product(id);

ALTER TABLE dbo.Supplier_Order
    ADD FOREIGN KEY (supplier_id) REFERENCES Proveedores.Supplier(id);

ALTER TABLE dbo.Supplier_Order_Detail
    ADD FOREIGN KEY (supplier_order_id) REFERENCES dbo.Supplier_Order(id_supplier_order),
    FOREIGN KEY (product_id) REFERENCES Productos.Product(id);

ALTER TABLE dbo.Inventory
    ADD FOREIGN KEY (product_id) REFERENCES Productos.Product(id),
    FOREIGN KEY (supplier_id) REFERENCES Proveedores.Supplier(id);


-- Inserción de datos en la tabla Seller (Vendedores)
INSERT INTO Vendedores.Seller (name, last_name, dni, email, phone, post, password)
VALUES
    ('Juan', 'Pérez', '12345678', 'juan.perez@email.com', '987654321', 'Administrador', '123456'),
    ('Ana', 'Gómez', '23456789', 'ana.gomez@email.com', '976543210', 'Vendedor', 'abc123'),
    ('Aleida', 'Campos', '34567890', 'aleida.campos@email.com', '975432109', 'Vendedor', 'password');
GO

-- Inserción de datos en la tabla Supplier (Proveedores)
INSERT INTO Proveedores.Supplier (name, direction, email, ruc, representative, email_representative, phone_representative, status, code_supplier)
VALUES
    ('Proveedor A', 'Av. Principal 123', 'proveedora@email.com', '12345678901', 'Carlos Pérez', 'carlos.perez@email.com', '987654321', 'A', 'P001'),
    ('Proveedor B', 'Calle Secundaria 456', 'proveedorb@email.com', '10987654321', 'Laura Gómez', 'laura.gomez@email.com', '976543210', 'A', 'P002');
GO

-- Inserción de datos en la tabla Product (Productos)
INSERT INTO Productos.Product (name, category, description, trade_mark, stock, price, expiration_date, status, code_product)
VALUES
    ('Coca-Cola', 'Bebidas', 'Bebida gaseosa 500ml', 'Coca-Cola', 500, 2.50, '2026-07-01', 'A', 'P001'),
    ('Inca Kola', 'Bebidas', 'Bebida gaseosa 500ml', 'Inca Kola', 600, 2.30, '2028-06-15', 'A', 'P002');
GO

-- Inserción de datos en la tabla Customer (Clientes)
INSERT INTO Clientes.Customer (name, last_name, document_type, number_document, birthdate, phone, email, address, status)
VALUES
    ('Pedro', 'López', 'DNI', '12345678', '1990-05-15', '987654321', 'pedro.lopez@email.com', 'Calle Ficticia 789', 'A'),
    ('Marta', 'Sánchez', 'DNI', '23456789', '1985-11-20', '976543210', 'marta.sanchez@email.com', 'Av. Libertad 123', 'A');
GO

-- Inserción de datos en la tabla Supplier_Order (Órdenes de Proveedores)
INSERT INTO dbo.Supplier_Order (order_date, delivery_date, supplier_id, code_order_supplier, order_status)
VALUES
    ('2024-10-01 10:00:00', '2024-10-05 12:00:00', 1, 'S001', 'A'),
    ('2024-10-03 14:30:00', '2024-10-07 11:00:00', 2, 'S002', 'A');
GO

-- Inserción de datos en la tabla Supplier_Order_Detail (Detalle de Órdenes de Proveedores)
INSERT INTO dbo.Supplier_Order_Detail (product_id, quantity, unit_price, total_price, supplier_order_id, description)
VALUES
    (1, 100, 2.00, 200.00, 1, 'Coca-Cola 500ml'),
    (2, 150, 1.80, 270.00, 2, 'Inca Kola 500ml');
GO

-- Inserción de datos en la tabla Sale (Ventas)
INSERT INTO dbo.Sale (customer_id, seller_id, date_sale, payment_method, status, total_sale)
VALUES
    (1, 1, '2024-10-01', 'Efectivo', 'A', 250.00),
    (2, 2, '2024-10-03', 'Tarjeta de Crédito', 'A', 345.00);
GO

-- Inserción de datos en la tabla Sale_Detail (Detalle de Ventas)
INSERT INTO dbo.Sale_Detail (sale_id, product_id, amount, unit_price, subtotal)
VALUES
    (1, 1, 100, 2.50, 250.00),
    (2, 2, 150, 2.30, 345.00);
GO

-- Inserción de datos en la tabla Inventory (Inventario)
INSERT INTO dbo.Inventory (product_id, entry_date, exit_date, purchase_price, sale_price, supplier_id, amount, description)
VALUES
    (1, '2024-09-01', NULL, 2.00, 2.50, 1, 500, 'Inventario inicial Coca-Cola'),
    (2, '2024-09-02', NULL, 1.80, 2.30, 2, 600, 'Inventario inicial Inca Kola');
GO

-- Verificar inserciones
SELECT * FROM Vendedores.Seller;
SELECT * FROM Proveedores.Supplier;
SELECT * FROM Productos.Product;
SELECT * FROM Clientes.Customer;
SELECT * FROM dbo.Sale;
SELECT * FROM dbo.Sale_Detail;
SELECT * FROM dbo.Inventory;
GO

SELECT * FROM Productos.Product;