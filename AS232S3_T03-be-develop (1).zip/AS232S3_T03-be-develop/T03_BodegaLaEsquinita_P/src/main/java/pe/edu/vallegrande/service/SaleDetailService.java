package pe.edu.vallegrande.service;

import pe.edu.vallegrande.db.ConexionDB;
import pe.edu.vallegrande.dto.Sale;
import pe.edu.vallegrande.dto.SaleDetail;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SaleDetailService {
    public Sale getSaleDetails(int saleId) throws Exception {
        String sql = "SELECT " +
                "s.id AS sale_id, " +
                "s.date_sale, " +
                "s.payment_method, " +
                "s.total_sale, " +
                "c.name AS customer_name, " +
                "c.last_name AS customer_last_name, " +
                "e.name AS seller_name, " +
                "e.last_name AS seller_last_name, " +
                "p.name AS product_name, " +
                "sd.amount, " +
                "sd.unit_price, " +
                "sd.subtotal " +
                "FROM dbo.sale s " +
                "JOIN Clientes.customer c ON s.customer_id = c.id " +
                "JOIN Vendedores.seller e ON s.seller_id = e.id " +
                "JOIN sale_detail sd ON s.id = sd.sale_id " +
                "JOIN Productos.product p ON sd.product_id = p.id " +
                "WHERE s.id = ?";

        Sale sale = new Sale();
        List<SaleDetail> details = new ArrayList<>();

        try (Connection connection = ConexionDB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, saleId);
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    if (sale.getId() == 0) { // Solo llenar información general una vez
                        sale.setId(resultSet.getInt("sale_id"));
                        sale.setDateSale(resultSet.getDate("date_sale"));
                        sale.setPaymentMethod(resultSet.getString("payment_method"));
                        sale.setTotalSale(resultSet.getBigDecimal("total_sale"));
                        sale.setCustomerName(resultSet.getString("customer_name") + " " + resultSet.getString("customer_last_name"));
                        sale.setSellerName(resultSet.getString("seller_name") + " " + resultSet.getString("seller_last_name"));
                    }

                    SaleDetail detail = new SaleDetail();
                    detail.setProductName(resultSet.getString("product_name"));
                    detail.setAmount(Integer.parseInt(resultSet.getString("amount")));
                    detail.setUnitPrice(resultSet.getBigDecimal("unit_price"));
                    detail.setSubtotal(resultSet.getBigDecimal("subtotal"));
                    details.add(detail);
                }
            }
        }
        sale.setDetails(details);
        return sale;
    }
}