package pe.edu.vallegrande.controller;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import pe.edu.vallegrande.dto.Supplier_order;
import pe.edu.vallegrande.dto.Supplier_order_detail;
import pe.edu.vallegrande.service.SupplierOrderDetailService;

import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.ArrayList;
import java.util.List;

@WebServlet("/RegistrarOrden")
public class Supplier_orderDetailController extends HttpServlet {

    private final SupplierOrderDetailService orderService = new SupplierOrderDetailService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws IOException {
        response.setContentType("application/json; charset=UTF-8");
        response.setCharacterEncoding("UTF-8");

        try {
            System.out.println("Procesando solicitud POST para registrar orden de proveedor...");

            // Leer JSON del cuerpo de la solicitud
            BufferedReader reader = request.getReader();
            StringBuilder json = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                json.append(line);
            }

            System.out.println("JSON recibido: " + json);

            // Parsear JSON
            Gson gson = new Gson();
            JsonObject data = gson.fromJson(json.toString(), JsonObject.class);

            // Crear objeto Supplier_order
            Supplier_order supplierOrder = new Supplier_order();
            supplierOrder.setSupplier_id(data.get("supplierId").getAsInt());
            supplierOrder.setCodeOrderSupplier(data.get("orderCode").getAsString());
            supplierOrder.setOrder_date(new Date(System.currentTimeMillis()));
            supplierOrder.setOrder_status('A');

            // Crear lista de Supplier_order_detail
            List<Supplier_order_detail> details = new ArrayList<>();
            JsonArray products = data.getAsJsonArray("orderDetails");

            for (JsonElement element : products) {
                JsonObject product = element.getAsJsonObject();
                Supplier_order_detail detail = new Supplier_order_detail();
                detail.setId_product(product.get("productId").getAsInt());
                detail.setQuantity(product.get("quantity").getAsInt());
                detail.setUnit_price(new BigDecimal(product.get("unit_price").getAsString()));
                detail.setTotal_price(new BigDecimal(product.get("total_price").getAsString()));
                details.add(detail);
            }

            System.out.println("Cabecera de la orden: " + supplierOrder);
            System.out.println("Detalles de la orden: " + details);

            // Registrar la orden con sus detalles
            boolean success = orderService.registrarOrden(supplierOrder, details);

            if (success) {
                System.out.println("Orden registrada exitosamente.");
                response.setStatus(HttpServletResponse.SC_OK);
                response.getWriter().write("{\"message\": \"Orden registrada correctamente\"}");
            } else {
                String errorMessage = "Error al registrar la orden: El servicio devolvió false.";
                System.err.println(errorMessage);
                response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
                response.getWriter().write("{\"message\": \"" + errorMessage + "\"}");
            }

        } catch (Exception e) {
            String detailedError = "Excepción al registrar la orden: " + e.getMessage();
            System.err.println(detailedError);
            e.printStackTrace(); // Imprimir el stacktrace completo en la consola

            // Enviar un mensaje detallado al cliente
            JsonObject errorResponse = new JsonObject();
            errorResponse.addProperty("error", detailedError);
            errorResponse.addProperty("exception", e.getClass().getName());
            errorResponse.addProperty("cause", e.getCause() != null ? e.getCause().toString() : "Sin causa específica");

            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            response.getWriter().write(errorResponse.toString());
        }
    }
}
