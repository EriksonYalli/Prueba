package pe.edu.vallegrande.service;

import pe.edu.vallegrande.dto.Supplier_order;
import pe.edu.vallegrande.dto.Supplier_order_detail;
import pe.edu.vallegrande.db.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SupplierOrderService {

    // Método para listar todas las órdenes de proveedores
    public List<Supplier_order> listarOrdenesProveedores() {
        List<Supplier_order> orders = new ArrayList<>();
        String sql = "SELECT so.id_supplier_order, so.order_date, so.supplier_id, so.code_order_supplier, " +
                "so.order_status, s.name AS supplier_name " +
                "FROM supplier_order so " +
                "JOIN Proveedores.supplier s ON so.supplier_id = s.id"; // Agregado esquema Proveedores

        try (
                Connection cn = ConexionDB.getConnection();
                PreparedStatement ps = cn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery()
        ) {
            while (rs.next()) {
                Supplier_order order = new Supplier_order();
                order.setId_supplier_order(rs.getInt("id_supplier_order"));
                order.setOrder_date(rs.getDate("order_date"));
                order.setSupplier_id(rs.getInt("supplier_id"));
                order.setCodeOrderSupplier(rs.getString("code_order_supplier"));
                order.setOrder_status(rs.getString("order_status").charAt(0)); // Convertir a char
                order.setSupplierName(rs.getString("supplier_name")); // Asignar nombre del proveedor
                orders.add(order);
            }
        } catch (SQLException e) {
            System.err.println("Error al listar las órdenes de proveedores: " + e.getMessage());
            e.printStackTrace();
        }

        return orders;
    }

    // Método para obtener una orden específica por ID
    public Supplier_order getSupplierOrderById(int supplierOrderId) {
        String sql = "SELECT so.id_supplier_order, so.order_date, so.supplier_id, so.code_order_supplier, " +
                "so.order_status, s.name AS supplier_name " +
                "FROM supplier_order so " +
                "JOIN Proveedores.supplier s ON so.supplier_id = s.id " + // Agregado esquema Proveedores
                "WHERE so.id_supplier_order = ?";
        Supplier_order order = null;

        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, supplierOrderId);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    order = new Supplier_order();
                    order.setId_supplier_order(rs.getInt("id_supplier_order"));
                    order.setOrder_date(rs.getDate("order_date"));
                    order.setSupplier_id(rs.getInt("supplier_id"));
                    order.setCodeOrderSupplier(rs.getString("code_order_supplier"));
                    order.setOrder_status(rs.getString("order_status").charAt(0)); // Convertir a char
                    order.setSupplierName(rs.getString("supplier_name")); // Asignar nombre del proveedor
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener la orden de proveedor: " + e.getMessage());
            e.printStackTrace();
        }

        return order;
    }

    // Método para listar los detalles de una orden específica
    public List<Supplier_order_detail> listarDetallesOrden(int supplierOrderId) {
        List<Supplier_order_detail> details = new ArrayList<>();
        String sql = "SELECT d.id_supplier_order_detail, d.quantity, d.unit_price, d.total_price, " +
                "d.id_supplier_order, d.id_product " +
                "FROM supplier_order_detail d " +
                "WHERE d.id_supplier_order = ?";

        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setInt(1, supplierOrderId);

            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Supplier_order_detail detail = new Supplier_order_detail();
                    detail.setId_supplier_order_detail(rs.getInt("id_supplier_order_detail"));
                    detail.setQuantity(rs.getInt("quantity"));
                    detail.setUnit_price(rs.getBigDecimal("unit_price"));
                    detail.setTotal_price(rs.getBigDecimal("total_price"));
                    detail.setId_supplier_order(rs.getInt("id_supplier_order"));
                    detail.setId_product(rs.getInt("id_product"));
                    details.add(detail);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al listar los detalles de la orden: " + e.getMessage());
            e.printStackTrace();
        }

        return details;
    }
}
