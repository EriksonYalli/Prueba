package pe.edu.vallegrande.prueba.proveedor;

import pe.edu.vallegrande.dto.Supplier;
import pe.edu.vallegrande.service.SupplierService;

import java.sql.SQLException;
import java.util.List;

public class ListarSupplierTest {
    public static void main(String[] args) throws SQLException {
        SupplierService service = new SupplierService();


        List<Supplier> suppliers = service.listar();

        // Recorre y muestra los datos de cada proveedor
        for (Supplier supplier : suppliers) {
            System.out.println("ID: " + supplier.getId());
            System.out.println("Nombre: " + supplier.getName());
            System.out.println("Dirección: " + supplier.getDirection());
            System.out.println("Email: " + supplier.getEmail());
            System.out.println("RUC: " + supplier.getRuc());
            System.out.println("Representante: " + supplier.getRepresentative());
            System.out.println("Email Representante: " + supplier.getEmailRepresentative());
            System.out.println("Teléfono Representante: " + supplier.getPhoneRepresentative());
            System.out.println("----------------------------------");
        }
    }
}
