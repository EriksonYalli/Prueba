package pe.edu.vallegrande.controller;

import pe.edu.vallegrande.dto.Supplier_order;
import pe.edu.vallegrande.service.SupplierOrderService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/OrdenesProveedores")
public class Supplier_orderPageController extends HttpServlet {

    private SupplierOrderService supplierOrderService = new SupplierOrderService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Obtener todas las órdenes de proveedores
        List<Supplier_order> supplierOrders = supplierOrderService.listarOrdenesProveedores();

        // Pasar los datos al JSP
        request.setAttribute("supplierOrders", supplierOrders);

        // Despachar al JSP
        request.getRequestDispatcher("ProveedorCompra.jsp").forward(request, response);
    }
}
