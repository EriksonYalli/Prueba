package pe.edu.vallegrande.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Sale {
    private int id;
    private int customerId;
    private int sellerId;
    private Date dateSale;  // Método generado: getDateSale()
    private String paymentMethod;
    private BigDecimal totalSale;  // Método generado: getTotalSale()
    private String customerName;  // Nombre del cliente
    private String sellerName;    // Nombre del vendedor
    private List<SaleDetail> details;

}