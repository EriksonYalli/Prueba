package pe.edu.vallegrande.service;

import pe.edu.vallegrande.dto.Supplier_order;
import pe.edu.vallegrande.dto.Supplier_order_detail;
import pe.edu.vallegrande.db.ConexionDB;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class SupplierOrderDetailService {

    // Método para registrar una orden con detalles
    public boolean registrarOrden(Supplier_order supplierOrder, List<Supplier_order_detail> details) {
        try (Connection con = ConexionDB.getConnection()) {
            con.setAutoCommit(false);
            System.out.println("Conexión establecida. Iniciando transacción...");

            int orderId = insertOrderHeader(con, supplierOrder);
            System.out.println("Cabecera de la orden insertada con ID: " + orderId);

            insertOrderDetails(con, orderId, details);
            System.out.println("Detalles de la orden insertados.");

            updateProductStock(con, details);
            System.out.println("Stock de productos actualizado.");

            con.commit();
            System.out.println("Transacción completada.");
            return true;
        } catch (SQLException e) {
            System.err.println("Error al registrar la orden: " + e.getMessage());
            return false;
        }
    }

    private int insertOrderHeader(Connection con, Supplier_order supplierOrder) throws SQLException {
        String sql = "INSERT INTO supplier_order(order_date, Supplier_id, code_order_supplier, order_status) " +
                "VALUES (?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS)) {
            ps.setDate(1, supplierOrder.getOrder_date());
            ps.setInt(2, supplierOrder.getSupplier_id());
            ps.setString(3, supplierOrder.getCodeOrderSupplier());
            ps.setString(4, String.valueOf(supplierOrder.getOrder_status()));
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    return rs.getInt(1); // Devuelve el ID generado
                }
                throw new SQLException("No se pudo obtener el ID de la orden");
            }
        }
    }

    private void insertOrderDetails(Connection con, int orderId, List<Supplier_order_detail> details) throws SQLException {
        String sql = "INSERT INTO supplier_order_detail(quantity, unit_price, total_price, supplier_order_id, product_id) " +
                "VALUES (?, ?, ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            for (Supplier_order_detail detail : details) {
                ps.setInt(1, detail.getQuantity());
                ps.setBigDecimal(2, detail.getUnit_price());
                ps.setBigDecimal(3, detail.getTotal_price());
                ps.setInt(4, orderId);
                ps.setInt(5, detail.getId_product());
                ps.addBatch();
            }
            ps.executeBatch(); // Ejecuta el batch
        }
    }

    private void updateProductStock(Connection con, List<Supplier_order_detail> details) throws SQLException {
        String sql = "UPDATE Productos.product SET stock = stock + ? WHERE id = ?";
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            for (Supplier_order_detail detail : details) {
                ps.setInt(1, detail.getQuantity());
                ps.setInt(2, detail.getId_product());
                ps.addBatch();
            }
            ps.executeBatch(); // Ejecuta el batch
        }
    }

    public List<Supplier_order_detail> getOrderDetailsByOrderId(int orderId) {
        // Aquí se asume que la tabla se llama 'products' y el campo es 'id'
        String sql = "SELECT d.id_supplier_order_detail, d.quantity, d.unit_price, d.total_price, " +
                "p.id AS product_id, p.name AS product_name, d.supplier_order_id " +
                "FROM supplier_order_detail d " +
                "JOIN Productos.product p ON d.product_id = p.id " +  // Usamos el esquema 'Productos'
                "WHERE d.supplier_order_id = ?";

        List<Supplier_order_detail> details = new ArrayList<>();

        try (Connection con = ConexionDB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, orderId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Supplier_order_detail detail = new Supplier_order_detail();
                    detail.setId_supplier_order_detail(rs.getInt("id_supplier_order_detail"));
                    detail.setQuantity(rs.getInt("quantity"));
                    detail.setUnit_price(rs.getBigDecimal("unit_price"));
                    detail.setTotal_price(rs.getBigDecimal("total_price"));
                    detail.setId_product(rs.getInt("product_id"));
                    detail.setProduct_name(rs.getString("product_name")); // Asumí que también quieres el nombre del producto
                    detail.setId_supplier_order(rs.getInt("supplier_order_id"));
                    details.add(detail);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error al obtener los detalles de la orden: " + e.getMessage());
            e.printStackTrace();
        }
        return details;
    }

}
