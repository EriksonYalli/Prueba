package pe.edu.vallegrande.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.sql.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Supplier_order {
    private int id_supplier_order;
    private Date order_date;
    private int Supplier_id;
    private String codeOrderSupplier;
    private char order_status;
    private String supplierName;


}
