package pe.edu.vallegrande.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigDecimal;
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Supplier_order_detail {
    private int id_supplier_order_detail;
    private int quantity;
    private BigDecimal unit_price;
    private BigDecimal total_price;
    private int id_supplier_order;
    private int id_product;
    private String product_name;

}