package pe.edu.vallegrande.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import pe.edu.vallegrande.dto.*;
import pe.edu.vallegrande.service.CustomerService;
import pe.edu.vallegrande.service.ProductService;
import pe.edu.vallegrande.service.SaleService;
import pe.edu.vallegrande.service.SellerService;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

@WebServlet({"/registrarVenta", "/nuevaVenta"})
public class SaleDetailController extends HttpServlet {

    private final SaleService saleService = new SaleService();
    private final ProductService productService = new ProductService();
    private final CustomerService customerService = new CustomerService();
    private final SellerService sellerService = new SellerService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        try {
            // Recuperar datos desde el servicio
            List<Customer> clients = customerService.getAllClients();
            List<Seller> sellers = sellerService.getAllSellers();
            List<Product> products = productService.listarActivos();

            // Pasar datos al JSP
            req.setAttribute("clients", clients);
            req.setAttribute("sellers", sellers);
            req.setAttribute("products", products);

            // Redirigir al JSP
            req.getRequestDispatcher("registrarVenta.jsp").forward(req, resp);
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("error.jsp");
        }
    }


    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String path = request.getServletPath();
        switch (path) {
            case "/registrarVenta":
                registrarVenta(request, response);
                break;
            default:
                response.sendRedirect("error.jsp");
                break;
        }
    }

    private void registrarVenta(HttpServletRequest request, HttpServletResponse response) throws IOException {
        try {
            // Información general de la venta
            int customerId = Integer.parseInt(request.getParameter("customerId"));
            int sellerId = Integer.parseInt(request.getParameter("sellerId"));
            String paymentMethod = request.getParameter("paymentMethod");
            BigDecimal totalSale = new BigDecimal(request.getParameter("totalSale"));

            // Crear objeto de venta
            Sale sale = new Sale();
            sale.setCustomerId(customerId);
            sale.setSellerId(sellerId);
            sale.setPaymentMethod(paymentMethod);
            sale.setTotalSale(totalSale);

            // Obtener detalles de la venta
            String[] productIds = request.getParameterValues("productId[]");
            String[] quantities = request.getParameterValues("quantity[]");

            List<SaleDetail> saleDetails = new ArrayList<>();
            for (int i = 0; i < productIds.length; i++) {
                SaleDetail detail = new SaleDetail();
                detail.setProductId(Integer.parseInt(productIds[i]));
                detail.setAmount(Integer.parseInt(quantities[i]));
                saleDetails.add(detail);
            }

            // Llamar al servicio para registrar la venta
            saleService.registerSale(sale, saleDetails);

            // Redirigir al listado de ventas
            response.sendRedirect("ventas");
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}