
package pe.edu.vallegrande.service;

import pe.edu.vallegrande.dto.Sale;
import pe.edu.vallegrande.dto.SaleDetail;

import java.math.BigDecimal;
import java.sql.SQLException;
import pe.edu.vallegrande.db.ConexionDB;
import pe.edu.vallegrande.dto.Sale;
import pe.edu.vallegrande.dto.Product;
import java.sql.*;
import java.util.List;
import java.util.ArrayList;

public class SaleService {

    public List<Sale> getAllSales() throws Exception {
        String sql = "SELECT " +
                "s.id AS sale_id, " +
                "s.date_sale AS sale_date, " +
                "s.payment_method, " +
                "s.total_sale, " +
                "c.name AS customer_name, " +
                "e.name AS seller_name " +
                "FROM dbo.sale s " +
                "JOIN Clientes.customer c ON s.customer_id = c.id " +
                "JOIN Vendedores.seller e ON s.seller_id = e.id";

        List<Sale> sales = new ArrayList<>();

        try (Connection connection = ConexionDB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Sale sale = new Sale();
                sale.setId(resultSet.getInt("sale_id"));
                sale.setDateSale(resultSet.getDate("sale_date"));
                sale.setPaymentMethod(resultSet.getString("payment_method"));
                sale.setTotalSale(resultSet.getBigDecimal("total_sale"));

                // Asegúrate de usar setters existentes en el DTO
                sale.setCustomerName(resultSet.getString("customer_name"));
                sale.setSellerName(resultSet.getString("seller_name"));

                sales.add(sale);
            }
        }
        return sales;
    }



    public void insertSaleTransaction(Sale sale, List<SaleDetail> details) throws Exception {
        String insertSaleSQL = "INSERT INTO Ventas.sale (customer_id, seller_id, date_sale, payment_method, total_sale) " +
                "VALUES (?, ?, GETDATE(), ?, ?)";
        String insertSaleDetailSQL = "INSERT INTO sale_detail (sale_id, product_id, amount, unit_price, subtotal) " +
                "VALUES (?, ?, ?, ?, ?)";

        try (Connection connection = ConexionDB.getConnection()) {
            connection.setAutoCommit(false);

            try (PreparedStatement saleStatement = connection.prepareStatement(insertSaleSQL, new String[]{"id"})) {
                // Insertar venta
                saleStatement.setInt(1, sale.getCustomerId());  // Usando getCustomerId() en lugar de getClientId()
                saleStatement.setInt(2, sale.getSellerId());  // Usando getSellerId() en lugar de getEmployeeId()
                saleStatement.setString(3, sale.getPaymentMethod());
                saleStatement.setBigDecimal(4, sale.getTotalSale());  // Usando getTotalSale() en lugar de getTotal()
                saleStatement.executeUpdate();

                // Obtener ID de la venta generada
                try (ResultSet generatedKeys = saleStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        int saleId = generatedKeys.getInt(1);

                        // Insertar detalles de la venta
                        try (PreparedStatement detailStatement = connection.prepareStatement(insertSaleDetailSQL)) {
                            for (SaleDetail detail : details) {
                                detailStatement.setInt(1, saleId);
                                detailStatement.setInt(2, detail.getProductId());
                                detailStatement.setString(3, String.valueOf(detail.getAmount()));  // Usando getAmount() de SaleDetail
                                detailStatement.setBigDecimal(4, detail.getUnitPrice());
                                detailStatement.setBigDecimal(5, detail.getSubtotal());
                                detailStatement.executeUpdate();
                            }
                        }
                    }
                }
            }

            // Confirmar la transacción
            connection.commit();
        } catch (SQLException e) {
            throw new Exception("Error al registrar la transacción de venta: " + e.getMessage(), e);
        }
    }

    public void registerSale(Sale sale, List<SaleDetail> details) throws Exception {
        String insertSaleSQL = "INSERT INTO sale (customer_id, seller_id, date_sale, payment_method, total_sale) " +
                "VALUES (?, ?, GETDATE(), ?, ?)";
        String insertSaleDetailSQL = "INSERT INTO sale_detail (sale_id, product_id, amount, unit_price, subtotal) " +
                "VALUES (?, ?, ?, ?, ?)";
        String updateStockSQL = "UPDATE Productos.product SET stock = stock - ? WHERE id = ? AND stock >= ?";

        try (Connection connection = ConexionDB.getConnection()) {
            connection.setAutoCommit(false);

            // Insertar venta
            int saleId;
            try (PreparedStatement saleStmt = connection.prepareStatement(insertSaleSQL, PreparedStatement.RETURN_GENERATED_KEYS)) {
                saleStmt.setInt(1, sale.getCustomerId());
                saleStmt.setInt(2, sale.getSellerId());
                saleStmt.setString(3, sale.getPaymentMethod());
                saleStmt.setBigDecimal(4, sale.getTotalSale());
                saleStmt.executeUpdate();

                // Obtener el ID generado de la venta
                try (ResultSet rs = saleStmt.getGeneratedKeys()) {
                    if (rs.next()) {
                        saleId = rs.getInt(1);
                    } else {
                        throw new SQLException("No se pudo obtener el ID de la venta");
                    }
                }
            }

            // Insertar detalles de la venta y actualizar stock
            try (PreparedStatement detailStmt = connection.prepareStatement(insertSaleDetailSQL);
                 PreparedStatement stockStmt = connection.prepareStatement(updateStockSQL)) {
                for (SaleDetail detail : details) {
                    // Insertar detalle de la venta
                    detailStmt.setInt(1, saleId);
                    detailStmt.setInt(2, detail.getProductId());
                    detailStmt.setInt(3, detail.getAmount());

                    // Calcular subtotal basado en cantidad y precio unitario
                    BigDecimal unitPrice = getProductPrice(connection, detail.getProductId());
                    BigDecimal subtotal = unitPrice.multiply(new BigDecimal(detail.getAmount()));

                    detailStmt.setBigDecimal(4, unitPrice);
                    detailStmt.setBigDecimal(5, subtotal);
                    detailStmt.executeUpdate();

                    // Actualizar el stock del producto
                    stockStmt.setInt(1, detail.getAmount());
                    stockStmt.setInt(2, detail.getProductId());
                    stockStmt.setInt(3, detail.getAmount()); // Verifica que haya stock suficiente
                    int rowsAffected = stockStmt.executeUpdate();

                    if (rowsAffected == 0) {
                        throw new SQLException("Stock insuficiente para el producto ID: " + detail.getProductId());
                    }
                }
            }

            // Confirmar transacción
            connection.commit();
        } catch (SQLException e) {
            throw new Exception("Error al registrar la venta: " + e.getMessage(), e);
        }
    }


    // Método para obtener el precio unitario de un producto
    private BigDecimal getProductPrice(Connection connection, int productId) throws SQLException {
        String sql = "SELECT price FROM Productos.product WHERE id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(sql)) {
            stmt.setInt(1, productId);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return rs.getBigDecimal("price");
                } else {
                    throw new SQLException("Producto no encontrado: ID = " + productId);
                }
            }
        }
    }

}
