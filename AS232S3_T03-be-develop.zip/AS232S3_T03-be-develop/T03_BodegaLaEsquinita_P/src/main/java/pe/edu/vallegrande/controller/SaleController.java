package pe.edu.vallegrande.controller;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import pe.edu.vallegrande.dto.Sale;  // Asegúrate de tener un DTO para Sale
import pe.edu.vallegrande.service.SaleService;
import pe.edu.vallegrande.service.CustomerService;
import pe.edu.vallegrande.service.SellerService;

@WebServlet("/ventas")
public class SaleController extends HttpServlet {

    private final SaleService saleService = new SaleService();  // Servicio para manejar las ventas
    private final CustomerService clientService = new CustomerService();  // Servicio para manejar los clientes
    private final SellerService sellerService = new SellerService();  // Servicio para manejar los vendedores

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            List<Sale> sales = saleService.getAllSales();
            request.setAttribute("sales", sales);  // Pasar lista de ventas al JSP
            request.getRequestDispatcher("sale.jsp").forward(request, response);  // Redirigir al JSP
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }

}