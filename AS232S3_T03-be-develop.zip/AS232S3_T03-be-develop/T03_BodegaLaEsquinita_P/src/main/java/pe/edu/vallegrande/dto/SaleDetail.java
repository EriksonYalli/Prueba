package pe.edu.vallegrande.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SaleDetail {
    private int id;
    private int saleId;
    private int productId;
    private int amount;
    private BigDecimal unitPrice;
    private BigDecimal subtotal;
    private char status;
    private String productName;
    private List<SaleDetail> details;
}