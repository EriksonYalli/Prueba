
package pe.edu.vallegrande.service;

import pe.edu.vallegrande.db.ConexionDB;
import pe.edu.vallegrande.dto.Seller;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class SellerService {

    public List<Seller> getAllSellers() throws SQLException {
        String sql = "SELECT id, name FROM Vendedores.seller";
        List<Seller> sellers = new ArrayList<>();

        try (Connection connection = ConexionDB.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {

            while (resultSet.next()) {
                Seller seller = new Seller();
                seller.setId(resultSet.getInt("id"));
                seller.setName(resultSet.getString("name"));
                sellers.add(seller);  // Agregar vendedor a la lista
            }
        }
        return sellers;
    }
}
