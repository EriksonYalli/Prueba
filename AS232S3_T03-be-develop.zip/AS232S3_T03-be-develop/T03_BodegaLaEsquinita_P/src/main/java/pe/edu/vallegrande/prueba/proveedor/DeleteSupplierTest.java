package pe.edu.vallegrande.prueba.proveedor;

import pe.edu.vallegrande.dto.Supplier;
import pe.edu.vallegrande.service.SupplierService;

import java.sql.SQLException;
import java.util.List;

public class DeleteSupplierTest {
    public static void main(String[] args) throws SQLException {
        SupplierService service = new SupplierService();
        int supplierIdToDelete = 1; // ID del proveedor que deseas eliminar (marcar como inactivo)

        // Elimina el proveedor (marca como inactivo) por ID
        int filasAfectadas = service.eliminar(supplierIdToDelete);
        if (filasAfectadas > 0) {
            System.out.println("Proveedor con ID " + supplierIdToDelete + " eliminado (marcado como inactivo)");
        } else {
            System.out.println("No se encontró el proveedor con ID " + supplierIdToDelete + " para eliminar.");
        }

        // Verifica que el proveedor ya no esté en la lista de proveedores activos
        List<Supplier> activeSuppliers = service.listar();
        boolean isStillActive = activeSuppliers.stream().anyMatch(supplier -> supplier.getId() == supplierIdToDelete);

        if (!isStillActive) {
            System.out.println("El proveedor ha sido eliminado de la lista de proveedores activos.");
        } else {
            System.out.println("Error: El proveedor todavía está en la lista de proveedores activos.");
        }
    }
}
