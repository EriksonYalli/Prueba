package pe.edu.vallegrande.controller;

import pe.edu.vallegrande.dto.Supplier;
import pe.edu.vallegrande.dto.Product;
import pe.edu.vallegrande.service.SupplierService;
import pe.edu.vallegrande.service.ProductService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

@WebServlet("/Registrar_OrdenProveedor")
public class Supplier_orderDetailPageController extends HttpServlet {

    private SupplierService supplierService = new SupplierService();
    private ProductService productService = new ProductService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // Cargar proveedores activos
        List<Supplier> suppliers = supplierService.listar();

        // Cargar productos activos
        List<Product> products = productService.listarActivos();

        // Enviar datos al JSP
        request.setAttribute("suppliers", suppliers);
        request.setAttribute("products", products);

        // Despachar al JSP
        request.getRequestDispatcher("ProveedorCompraDetalle.jsp").forward(request, response);
    }
}
