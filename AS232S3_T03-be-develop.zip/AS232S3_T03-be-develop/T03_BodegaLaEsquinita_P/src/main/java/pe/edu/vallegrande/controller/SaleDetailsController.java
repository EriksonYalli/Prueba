
package pe.edu.vallegrande.controller;

import pe.edu.vallegrande.dto.Sale;
import pe.edu.vallegrande.service.SaleDetailService;
import pe.edu.vallegrande.service.SaleService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/verDetalleVenta")
public class SaleDetailsController extends HttpServlet {
    private final SaleDetailService saleService = new SaleDetailService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException, IOException {
        try {
            int saleId = Integer.parseInt(request.getParameter("id"));
            Sale sale = saleService.getSaleDetails(saleId); // Obtener detalles de la venta
            request.setAttribute("sale", sale); // Pasar venta al JSP
            request.getRequestDispatcher("saleDetails.jsp").forward(request, response);
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("error.jsp");
        }
    }
}
